library(ggplot2)
library(forcats)
require(ggplot2)

#read file into R
#reference:https://rstudio.github.io/leaflet/
myData <- read.csv('assignment-02-data-formated.csv')


map1 <- leaflet(myData)%>%addTiles()%>%addMarkers(lng = ~longitude,
                                                 lat = ~latitude,
                                                 labelOptions = labelOptions(noHide = T,style = list("font-style" = "oblique" )))
map1
