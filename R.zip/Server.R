library(shiny)
library(ggplot2)
library(leaflet)


#read data
myData = read.csv('assignment-02-data-formated.csv')

#change value into number
myData$value = as.numeric(sub("%","",myData$value))/100
shinyServer(function(input,output)
{
  coralTP = reactive ({
  switch(input$coralType,
        "all" = "all",
        "blue corals" = "blue corals",
        "soft corals" = "soft corals",
        "hard corals" = "hard corals",
        "sea pens" = "sea pens",
        "sea fans" = "sea fans")
    
  })
  smooth = reactive({
    switch(input$smoother,
           "auto method" = "auto",
           "lm"= 'lm',
           "glm" = "glm",
           "gam" = "gam",
            "loess" = " loess" )
    
    })

  output$caption = renderText({
    
    "Bleaching Plot"
  })
  
  
  output$plot = renderPlot({
    ggplot(myData[myData$coralType == coralTP(),], aes(x=year, y=value,group=1))+
      geom_point( )+ stat_smooth(method = smooth())+ facet_grid(.~location)
  
})
  output$caption2 = renderText({
    
    "Leaftect Map"
  })

  output$leaflet = renderLeaflet({
    map <- leaflet(myData)%>%addTiles()%>%addMarkers(lng = ~longitude,
                                                     lat = ~latitude,
                                                     labelOptions = labelOptions(noHide = T,style = list("font-style" = "oblique" )))
    map
    })
  
  
  
}




)















