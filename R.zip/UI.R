library(shiny)
library(ggplot2)
library(leaflet)

#ui

shinyUI(fluidPage(
  
#add new 

  headerPanel("Corals Bleaching"),
  
  #setting SidebarLayout
  sidebarLayout(
    sidebarPanel(
      selectInput("coralType", "Please Select Coral Type:",
                  
                  choices = c("blue corals",
                              "soft corals",
                              "hard corals",
                              "sea pens",
                              "sea fans")
                  ),
      selectInput("smoother", "Please Select Smoother Method:",
                  
                  choices = c("auto method",
                              "lm",
                              "glm",
                              "gam",
                              "loess")
      )
    ),
    
    mainPanel(
      h3(textOutput("caption")),
      plotOutput("plot"),
      h3(textOutput("caption2")),
      leafletOutput("leaflet")
      
    )
    
    
    
  )
  
  
  
)


)



