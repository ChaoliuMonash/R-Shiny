library(ggplot2)
library(forcats)
require(ggplot2)

#read file into R
myData <- read.csv('assignment-02-data-formated.csv')

#change value into number
myData$value = as.numeric(sub("%","",myData$value))/100

#reording data
#reference:https://www.r-graph-gallery.com/267-reorder-a-variable-in-ggplot2.html
myData$location = fct_reorder(myData$location, myData$longitude)

#ggpplot
#reference:https://plotly.com/ggplot2/stat_smooth/

Static = ggplot(myData, aes(x = year, y = value,group=1, color=coralType))+
  geom_line()+ stat_smooth()+ facet_grid(myData$location~myData$coralType)
 
print(Static)



